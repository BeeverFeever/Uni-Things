package com.example.mtassessment2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Activity1 extends AppCompatActivity {
    public static final String EXTRA_READER_TYPE = "reader_type";
    public static final String READER_BARCODE  = "Barcode Reader";
    public static final String READER_CONTENT  = "Content Reader";
    public static final String READER_TEXT     = "Text Reader";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity1);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ImageButton btnBarcode = findViewById(R.id.imgBtnBarcode);
        ImageButton btnContent = findViewById(R.id.imgBtnContent);
        ImageButton btnText    = findViewById(R.id.imgBtnText);
        Button      btnList    = findViewById(R.id.btnListAnalysed);

        btnBarcode.setOnClickListener(v -> openActivity2(READER_BARCODE));
        btnContent.setOnClickListener(v -> openActivity2(READER_CONTENT));
        btnText.setOnClickListener(v   -> openActivity2(READER_TEXT));

        btnList.setOnClickListener(v -> {
            startActivity(new Intent(this, Activity6.class));
        });
    }

    private void openActivity2(String readerType) {
        Intent intent = new Intent(this, Activity2.class);
        intent.putExtra(EXTRA_READER_TYPE, readerType);
        startActivity(intent);
    }
}
