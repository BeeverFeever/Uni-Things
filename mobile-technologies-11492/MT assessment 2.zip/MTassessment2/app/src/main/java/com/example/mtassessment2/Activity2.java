package com.example.mtassessment2;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Activity2 extends AppCompatActivity {

    private static final String TAG = "Activity2";
    private static final int REQUEST_CAMERA_PERMISSION = 100;
    private static final int REQUEST_STORAGE_PERMISSION = 101;
    private ImageView imageView;
    private TextView tvResult;
    private Button btnEditResult;
    private String readerType;
    private Uri photoUri;       // URI of the photo taken by camera
    private Bitmap currentBitmap;
    private String currentFilename;
    private String mlKitResult = "";

    private final ActivityResultLauncher<Intent> cameraLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == RESULT_OK) {
                try {
                    currentBitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), photoUri);
                    imageView.setImageBitmap(currentBitmap);
                    runMlKit(currentBitmap);
                } catch (IOException e) {
                    Toast.makeText(this, "Failed to load photo", Toast.LENGTH_SHORT).show();
                }
            }
        });

    private final ActivityResultLauncher<Intent> galleryLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                Uri selectedUri = result.getData().getData();
                try {
                    currentBitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), selectedUri);
                    // save a copy to internal storage so we have a stable filename
                    currentFilename = saveImageToInternalStorage(currentBitmap);
                    imageView.setImageBitmap(currentBitmap);
                    runMlKit(currentBitmap);
                } catch (IOException e) {
                    Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show();
                }
            }
        });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity2);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        readerType = getIntent().getStringExtra(Activity1.EXTRA_READER_TYPE);
        if (readerType == null) readerType = Activity1.READER_BARCODE;

        imageView = findViewById(R.id.imageView2);
        tvResult = findViewById(R.id.tvResult);
        btnEditResult = findViewById(R.id.btnEditResult);
        Button btnCamera = findViewById(R.id.btnOpenCamera);
        Button btnLoad = findViewById(R.id.btnLoadImage);

        setTitle(readerType);
        setPlaceholderImage();

        btnCamera.setOnClickListener(v -> checkCameraPermissionAndOpen());
        btnLoad.setOnClickListener(v -> checkStoragePermissionAndOpen());

        btnEditResult.setOnClickListener(v -> {
            if (currentFilename == null) {
                Toast.makeText(this, "No image filename available", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent intent = new Intent(this, Activity5.class);
            intent.putExtra(Activity5.EXTRA_READER,   readerType);
            intent.putExtra(Activity5.EXTRA_TEXT,     mlKitResult);
            intent.putExtra(Activity5.EXTRA_FILENAME, currentFilename);
            startActivity(intent);
        });

        btnEditResult.setVisibility(View.GONE); // hidden until analysis is done
    }

    private void setPlaceholderImage() {
        switch (readerType) {
            case Activity1.READER_BARCODE:
                imageView.setImageResource(R.drawable.img_barcode);
                break;
            case Activity1.READER_CONTENT:
                imageView.setImageResource(R.drawable.img_content);
                break;
            case Activity1.READER_TEXT:
                imageView.setImageResource(R.drawable.img_text);
                break;
        }
    }

    private void checkCameraPermissionAndOpen() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
        } else {
            openCamera();
        }
    }

    private void checkStoragePermissionAndOpen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_MEDIA_IMAGES}, REQUEST_STORAGE_PERMISSION);
                return;
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_STORAGE_PERMISSION);
                return;
            }
        }
        openGallery();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (requestCode == REQUEST_CAMERA_PERMISSION)  openCamera();
            if (requestCode == REQUEST_STORAGE_PERMISSION) openGallery();
        } else {
            Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
        }
    }

    private void openCamera() {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        File photoFile = createImageFile();
        if (photoFile != null) {
            photoUri = FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".fileprovider", photoFile);
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
            cameraLauncher.launch(cameraIntent);
        }
    }

    private File createImageFile() {
        String timestamp = new SimpleDateFormat("yyyyMMddHHmmssSSS", Locale.getDefault()).format(new Date());
        currentFilename = timestamp;
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        if (storageDir != null && !storageDir.exists()) {
            storageDir.mkdirs();
        }
        return new File(storageDir, timestamp + ".jpg");
    }

    private void openGallery() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        galleryLauncher.launch(galleryIntent);
    }

    private String saveImageToInternalStorage(Bitmap bitmap) {
        String filename = new SimpleDateFormat("yyyyMMddHHmmssSSS", Locale.getDefault()).format(new Date());
        File file = new File(getFilesDir(), filename + ".jpg");
        try (java.io.FileOutputStream fos = new java.io.FileOutputStream(file)) {
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos);
        } catch (IOException e) {
            Toast.makeText(this, "Failed to save image to local storage", Toast.LENGTH_SHORT).show();
        }
        return filename;
    }

    private void runMlKit(Bitmap bitmap) {
        tvResult.setText("Analysing…");
        btnEditResult.setVisibility(View.GONE);
        InputImage image = InputImage.fromBitmap(bitmap, 0);

        switch (readerType) {
            case Activity1.READER_BARCODE:
                runBarcodeScanner(image);
                break;
            case Activity1.READER_CONTENT:
                runImageLabeler(image);
                break;
            case Activity1.READER_TEXT:
                runTextRecognizer(image);
                break;
        }
    }

    private void runBarcodeScanner(InputImage image) {
        BarcodeScannerOptions options = new BarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS)
            .build();
        BarcodeScanner scanner = BarcodeScanning.getClient(options);
        scanner.process(image)
            .addOnSuccessListener(barcodes -> {
                if (barcodes.isEmpty()) {
                    mlKitResult = "No barcode detected";
                } else {
                    StringBuilder sb = new StringBuilder("Detected barcode:\n");
                    for (Barcode b : barcodes) {
                        sb.append(b.getRawValue()).append("; ");
                    }
                    mlKitResult = sb.toString().trim();
                }
                showResult(mlKitResult);
            })
            .addOnFailureListener(e -> showResult("Barcode scan failed: " + e.getMessage()));
    }

    private void runImageLabeler(InputImage image) {
        ImageLabelerOptions options = new ImageLabelerOptions.Builder()
            .setConfidenceThreshold(0.6f)
            .build();
        ImageLabeler labeler = ImageLabeling.getClient(options);
        labeler.process(image)
            .addOnSuccessListener(labels -> {
                if (labels.isEmpty()) {
                    mlKitResult = "No content recognised";
                } else {
                    StringBuilder sb = new StringBuilder("Recognised image content:\n");
                    int i = 1;
                    for (com.google.mlkit.vision.label.ImageLabel label : labels) {
                        sb.append(i++).append(". ")
                          .append(label.getText())
                          .append(String.format(Locale.getDefault(), " (%.0f%% confidence)\n", label.getConfidence() * 100));
                    }
                    mlKitResult = sb.toString().trim();
                }
                showResult(mlKitResult);
            })
            .addOnFailureListener(e -> showResult("Labelling failed: " + e.getMessage()));
    }

    private void runTextRecognizer(InputImage image) {
        TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        recognizer.process(image)
            .addOnSuccessListener(result -> {
                String text = result.getText();
                mlKitResult = text.isEmpty()
                    ? "No text extracted"
                    : "Extracted text:\n" + text;
                showResult(mlKitResult);
            })
            .addOnFailureListener(e -> showResult("Text recognition failed: " + e.getMessage()));
    }

    private void showResult(String result) {
        tvResult.setText(result);
        btnEditResult.setVisibility(View.VISIBLE);

        // auto save the scan result to firebase
        if (currentFilename != null) {
            DatabaseReference db = FirebaseDatabase.getInstance().getReference("Storage");
            AnalysedImage record = new AnalysedImage(currentFilename, readerType, result);
            db.child(currentFilename).setValue(record);
        }
    }
}
