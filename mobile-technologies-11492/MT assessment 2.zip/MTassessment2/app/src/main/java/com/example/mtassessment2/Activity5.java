package com.example.mtassessment2;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.File;

public class Activity5 extends AppCompatActivity {
    public static final String EXTRA_READER   = "extra_reader";
    public static final String EXTRA_TEXT     = "extra_text";
    public static final String EXTRA_FILENAME = "extra_filename";

    private EditText etReader;
    private EditText etText;
    private ImageView imageView5;
    private String filename;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity5);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        imageView5 = findViewById(R.id.imageView5);
        etReader   = findViewById(R.id.etReader);
        etText     = findViewById(R.id.etText);
        Button btnSave = findViewById(R.id.btnSave5);

        // retrieve data passed from Activity2 or Activity7
        String reader = getIntent().getStringExtra(EXTRA_READER);
        String text = getIntent().getStringExtra(EXTRA_TEXT);
        filename = getIntent().getStringExtra(EXTRA_FILENAME);

        etReader.setText(reader);
        etText.setText(text);

        loadImage(filename);

        btnSave.setOnClickListener(v -> saveToFirebase());
    }

    private void loadImage(String filename) {
        if (filename == null || filename.isEmpty()) return;

        File file = findImageFile(filename);
        if (file != null) {
            Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
            imageView5.setImageBitmap(bitmap);
        }
    }

    private File findImageFile(String filename) {
        String[] extensions = {".jpg", ".png", ".jpeg"};
        File[] dirs = {getFilesDir(), getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES)};
        
        for (File dir : dirs) {
            if (dir == null) continue;
            for (String ext : extensions) {
                File file = new File(dir, filename + ext);
                if (file.exists()) {
                    return file;
                }
            }
        }
        return null;
    }

    private void saveToFirebase() {
        String readerValue = etReader.getText().toString().trim();
        String textValue   = etText.getText().toString().trim();

        if (filename == null || filename.isEmpty()) {
            Toast.makeText(this, "No image to save", Toast.LENGTH_SHORT).show();
            return;
        }

        DatabaseReference db = FirebaseDatabase.getInstance().getReference("Storage");
        AnalysedImage record = new AnalysedImage(filename, readerValue, textValue);

        // use filename as the key so we can update existing records cleanly
        db.child(filename).setValue(record)
            .addOnSuccessListener(unused -> {
                Toast.makeText(this, "Saved!", Toast.LENGTH_SHORT).show();
                // open Activity6 after saving
                Intent intent = new Intent(this, Activity6.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            })
            .addOnFailureListener(e ->
                Toast.makeText(this, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show()
            );
    }
}
