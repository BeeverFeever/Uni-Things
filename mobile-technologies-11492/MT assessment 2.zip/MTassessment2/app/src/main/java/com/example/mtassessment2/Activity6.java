package com.example.mtassessment2;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Activity6 extends AppCompatActivity {
    private ListView listView;
    private ImageListAdapter adapter;
    private final List<AnalysedImage> imageList = new ArrayList<>();
    private DatabaseReference dbRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity6);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        listView = findViewById(R.id.listView6);
        Button btnAdd = findViewById(R.id.btnAdd6);

        dbRef = FirebaseDatabase.getInstance().getReference("Storage");
        adapter = new ImageListAdapter();
        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            AnalysedImage item = imageList.get(position);
            Intent intent = new Intent(this, Activity7.class);
            intent.putExtra(Activity7.EXTRA_FILENAME, item.getFilename());
            intent.putExtra(Activity7.EXTRA_READER, item.getReader());
            intent.putExtra(Activity7.EXTRA_TEXT, item.getText());
            startActivity(intent);
        });

        btnAdd.setOnClickListener(v -> {
            Intent intent = new Intent(this, Activity1.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadFromFirebase();   // reload every time we come back to this screen
    }

    private void loadFromFirebase() {
        dbRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                imageList.clear();
                for (DataSnapshot child : snapshot.getChildren()) {
                    AnalysedImage item = child.getValue(AnalysedImage.class);
                    if (item != null) imageList.add(item);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(Activity6.this, "Load failed: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private class ImageListAdapter extends ArrayAdapter<AnalysedImage> {
        ImageListAdapter() {
            super(Activity6.this, R.layout.list_item, imageList);
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
            }

            AnalysedImage item = imageList.get(position);
            ImageView ivThumb = convertView.findViewById(R.id.ivThumb);
            TextView tvLabel = convertView.findViewById(R.id.tvItemLabel);

            tvLabel.setText(item.getText());

            // load thumbnail from local storage
            Bitmap bmp = loadBitmapForFilename(item.getFilename());
            if (bmp != null) {
                ivThumb.setImageBitmap(bmp);
            } else {
                ivThumb.setImageResource(android.R.drawable.ic_menu_gallery);
            }

            return convertView;
        }
    }

    private Bitmap loadBitmapForFilename(String filename) {
        if (filename == null) return null;
        File file = new File(getFilesDir(), filename + ".jpg");
        if (!file.exists()) {
            file = new File(getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES), filename + ".jpg");
        }
        if (file.exists()) {
            return BitmapFactory.decodeFile(file.getAbsolutePath());
        }
        return null;
    }
}
