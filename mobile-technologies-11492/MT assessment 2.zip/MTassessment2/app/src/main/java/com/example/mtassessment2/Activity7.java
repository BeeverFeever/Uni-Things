package com.example.mtassessment2;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.File;

public class Activity7 extends AppCompatActivity {
    public static final String EXTRA_FILENAME = "a7_filename";
    public static final String EXTRA_READER = "a7_reader";
    public static final String EXTRA_TEXT = "a7_text";

    private String filename;
    private String reader;
    private String text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity7);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        filename = getIntent().getStringExtra(EXTRA_FILENAME);
        reader = getIntent().getStringExtra(EXTRA_READER);
        text = getIntent().getStringExtra(EXTRA_TEXT);

        ImageView ivImage = findViewById(R.id.imageView7);
        TextView tvReader = findViewById(R.id.tvReader7);
        TextView tvText = findViewById(R.id.tvText7);
        Button btnEdit = findViewById(R.id.btnEdit7);
        Button btnDelete = findViewById(R.id.btnDelete7);
        Button btnCancel = findViewById(R.id.btnCancel7);

        tvReader.setText(reader);
        tvText.setText(text);
        loadImage(ivImage, filename);

        btnEdit.setOnClickListener(v -> {
            Intent intent = new Intent(this, Activity5.class);
            intent.putExtra(Activity5.EXTRA_READER,   reader);
            intent.putExtra(Activity5.EXTRA_TEXT,     text);
            intent.putExtra(Activity5.EXTRA_FILENAME, filename);
            startActivity(intent);
            finish();
        });

        btnDelete.setOnClickListener(v -> deleteItem());
        btnCancel.setOnClickListener(v -> {
            Intent intent = new Intent(this, Activity6.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        });
    }

    private void loadImage(ImageView iv, String filename) {
        if (filename == null) return;
        File file = new File(getFilesDir(), filename + ".jpg");
        if (!file.exists()) {
            file = new File(getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES), filename + ".jpg");
        }
        if (file.exists()) {
            Bitmap bmp = BitmapFactory.decodeFile(file.getAbsolutePath());
            iv.setImageBitmap(bmp);
        }
    }

    private void deleteItem() {
        DatabaseReference db = FirebaseDatabase.getInstance().getReference("Storage").child(filename);

        db.removeValue()
            .addOnSuccessListener(unused -> {
                Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, Activity6.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            })
            .addOnFailureListener(e ->
                Toast.makeText(this, "Delete failed: " + e.getMessage(), Toast.LENGTH_SHORT).show()
            );
    }
}
