package com.example.mtassessment2;

public class AnalysedImage {
    private String filename;   // unique timestamp-based filename used to locate image on device
    private String reader;     // "Barcode Reader" | "Content Reader" | "Text Reader"
    private String text;       // ML Kit result text (editable by user)

    // Required empty constructor for Firebase deserialization
    public AnalysedImage() {}

    public AnalysedImage(String filename, String reader, String text) {
        this.filename = filename;
        this.reader   = reader;
        this.text     = text;
    }

    public String getFilename() { return filename; }
    public void setFilename(String filename) { this.filename = filename; }

    public String getReader() { return reader; }
    public void setReader(String reader) { this.reader = reader; }

    public String getText() { return text; }
    public void setText(String text) { this.text = text; }
}
